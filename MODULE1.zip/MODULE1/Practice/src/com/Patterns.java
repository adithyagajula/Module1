package com;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Patterns {
	public static void main(String[] args) {
		
		String input = "Shop.Mop,Hopping,Chopping";
		Pattern pattern = Pattern.compile("pp");
		Matcher matcher = pattern.matcher(input);
		System.out.println(matcher.matches());
		while(matcher.find()) {
			System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());
		}
		
	}

}
