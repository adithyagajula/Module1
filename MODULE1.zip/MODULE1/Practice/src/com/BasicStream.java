package com;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class BasicStream {
	public static void main(String[] args) {
		
		Stream<String> stream = Stream.of("A","D","I","T","H","Y","A","\n");
		stream.forEach((location)->System.out.print(location));
		List<String> locations = Arrays.asList(new String[] {"hyderabad","mumbai","chennai","delhi"});
		stream = locations.stream();
		stream.forEach(System.out::println);
		//length
		List<String>words=Arrays.asList("Hello","Adithya","Gajula");
		words.stream().map(str->str.length()).forEach(System.out::println);
		//filter
		List<Integer>listInt = Arrays.asList(11,2,44,55,22,77);
		listInt.stream().filter(num->num>10).forEach(num->System.out.println(num));
		
		
		
	//	List<Integer>
		List<Integer>IntList = Arrays.asList(1,3,8,2,9);
		Optional<Integer>result = IntList.stream().reduce((a,b)->a+b);
		if(result.isPresent())
		{
			System.out.println("Result is : " +result.get());
		}
		}
		
	}


