package aadi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcEx2 {
	public static void main(String[] args) throws ClassNotFoundException {
		
		try(PreparedStatement psmt = con.prepareStatement(SQL,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY))
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			Statement stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement("insert into emp2 values(?,?,?)");
			//stmt.execute("create table emp1(eid number(5))");
			//stmt.execute("insert into emp1 values(101)");
			//stmt.execute("insert into emp1 values(102)");
			//stmt.execute("insert into emp1 values(103)");
			pst.setInt(1, 101);
			pst.setString(2,"adithya");
			pst.setInt(3, 20000);
			ResultSet rs = stmt.executeQuery("select * from emp2");
			while(rs.next())
			{
				int eid=rs.getInt(1);
				String ename=rs.getString(2);
				int esal=rs.getInt(3);
				System.out.println(eid+" "+ename+" "+esal);
				
			}
			
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}
}