package aadi;


import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
public class exam1 {




    public static void main(String[] args) {



        // TODO Auto-generated method stub
        Scanner sc =new Scanner(System.in);
        //Fill the UI code
        Shop obj=new Shop();


        System.out.println("Enter the no of Face Creams you want to store");


        int number=sc.nextInt();
        //int[] a= new int[number];
        String[] value= new String[number];
        int[] key= new int[number];
        
        for(int i=0;i<number;i++){
            System.out.println("Enter the Key"+i);
            key[i]=sc.nextInt();
            System.out.println("Enter the value"+i);
            sc.nextLine();
            value[i]=sc.nextLine();


        }
        HashMap<Integer,String> hash= new HashMap<>();
        obj.setProductMap(hash);


        for(int i=0;i<number;i++){
            obj.addProductDetails(key[i],value[i]);
        }for(int i=0;i<number;i++){
            System.out.println(key[i]+" "+obj.getProductMap().get(key[i]));
        }
        System.out.println("Enter the product type to be searched");
        String d=sc.next();
        Iterator<String> i = obj.searchBasedOnproduct(d).iterator();
        System.out.println("The ArrayList elements are:");
        while (i.hasNext()) {
            System.out.println(i.next());
        }



    }}










    
public class Shop {
private Map<Integer,String> productMap;
    
    public Map<Integer, String> getProductMap() {
        
        
        return productMap;
    }


    public void setProductMap(Map<Integer, String> productMap) {
        
        this.productMap = productMap;
    }


    //This method should add the serialNumber as key and productName value into the productMap map
    public void addProductDetails(int serialNumber,String productName)
    {
        productMap.put(serialNumber,productName);
    }
    
    /*
     * This method should search the product based on the producttype and add those products
     * into the list and return the list.
     * For example: If the map contains the key and value as:
     * 1    Fair And Lovely Cream
        2    Lakme Lotion
        3    Fair One Lotion
        4    Ponds Cream
        5    Baby Cream
        if the product type is lotion the output should be
        Lakme Lotion
        Fair One Lotion


     */
    public List<String> searchBasedOnproduct(String productType){
        List<String> array= new ArrayList<>();
        int a;boolean b;
        for(int i =1;i<=5;i++)
        {
            if(productMap.containsKey(i)){
        a= productMap.get(i).indexOf(productType);
            if(a!=-1){
                array.add(productMap.get(i));
            }}}
        return array;
        
}}
 





public static void main(String[] args) 
{
    DomainBO bo=new DomainBO();
    do{
    System.out.println("1.add DNS details");
    System.out.println("2.Find matching Domain Name");
    System.out.println("3.Exit");
    System.out.println("Enter Your choice");
    Scanner sc=new Scanner(System.in);
    int ch=sc.nextInt();
    switch(ch)
    {
        case 1:
            System.out.println("Enter the domain name");
            String domain=sc.nextLine();
            if(domain.equals(""))
            {
                domain=sc.nextLine();
            }
            System.out.println("Enter the IP address");
            String IP=sc.nextLine();
            if(IP.equals(""))
                IP=sc.nextLine();
                bo.addDNDdetails(domain,IP);
            break;
        case 2:
            System.out.println("Enter the IP address to find the domain name");
            String ip_addr=sc.nextLine();
            if(ip_addr.equals(""))
            {
                ip_addr=sc.nextLine();
            }
            String find=bo.findDomainName(ip_addr);
            if(find.equals("")){
                System.out.println("No matching domain name found");
            }
            else{
                System.out.println(find);
            }
            break;
            
        case 3:
            break;
         default:
                break;
    }
}while(ch<4&&ch>0)
System.out.println("Thank you for using the Application");
}







