package aadi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcSample {
	public static void main(String[] args) throws ClassNotFoundException {
		
		try(PreparedStatement psmt = con.prepareStatement(SQL,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY))
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			Statement stmt = con.createStatement();
			//stmt.execute("create table emp4(eid number(5),ename varchar2(20),esal number(10))");
			//stmt.execute("insert into emp4 values(101,'adithya',10000,9618463980)");
			//stmt.execute("insert into emp4 values(102,'sharan',12000,8179700938)");
			//stmt.execute("insert into emp4 values(103,'shashi',14000,8919732039)");
			//stmt.execute("update emp4 set ename='hari' where eid=101");
			//stmt.execute("alter table emp4 add ecell number(10)");
			stmt.execute("delete from emp4 where eid=103");
			ResultSet rs = stmt.executeQuery("select * from emp4");
			while(rs.next())
			{
				int eid=rs.getInt(1);
				String ename=rs.getString(2);
				int esal=rs.getInt(3);
				long ecell=rs.getLong(4);
				
				System.out.println(eid+" "+ename+" "+esal+" "+ecell);
				
			}
			
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}

	
}
