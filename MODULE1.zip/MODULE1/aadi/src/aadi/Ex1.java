package aadi;

import java.util.Map;
import java.util.TreeMap;

public class Ex1 {
	static int freq;
public static void main(String[] args) {
String[] words = new String[] {"aaa", "bbb", "ccc", "aaa"};
Map<String, Integer> m = new TreeMap<String, Integer>();
for (String word : words) {
freq = m.get(word);
//m.put(word, freq ==null ? 1 : freq + 1);
}
System.out.println(m);
}
}