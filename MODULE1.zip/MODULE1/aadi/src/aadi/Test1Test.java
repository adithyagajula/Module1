package aadi;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Test1Test {
	Test1 t = null;

	@BeforeEach
	void setUp() throws Exception {
		 t = new Test1();
	}

	@AfterEach
	void tearDown() throws Exception {
		t=null;
	}

	@Test
	void testCalculatesum() {
		//fail("Not yet implemented");
		assertEquals(10, t.calculatesum(5,5));
	}

	@Test
	void testCalculatesub() {
		//fail("Not yet implemented");
		assertEquals(10, t.calculatesub(15,5));
		
	}

	@Test
	void testCalculatediv() {
		//fail("Not yet implemented");
		assertEquals(10, t.calculatediv(100,10));
		
	}

}
