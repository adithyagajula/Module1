package aadi;

public class Test1 {

	public int calculatesum(int a,int b)
	{
		return a+b;
		
	}
	public int calculatesub(int a,int b)
	{
		return a-b;
		
	}
	public int calculatediv(int a,int b)
	{
		return a/b;
	}
}
