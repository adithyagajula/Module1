package aadi;

import java.util.*;
import java.util.Scanner;
import java.lang.*;
public class Main {

 

    public static void main(String[] args) {
        String s;
        //int n;
        Scanner sc=new Scanner(System.in);
        //System.out.println("Enter the size:");
        //n = sc.nextInt();
        //if(n!=5)
        //System.out.println("Invalid Input");
            //System.out.println("Enter time:");
              s = sc.next();
              if(s.length()!=5)
              System.out.println("Invalid Input");
              else{
              String s1[] = s.split(":");
              try{
              int a = Integer.parseInt(s1[0]);
              int b = Integer.parseInt(s1[1]);
              if(a>=0&&a<24)
              {
                  if(b>=0&&b<60)
                  {
                      if(a<=12)
                      {
                          if(a==0)
                          {
                              a = a+12;
                              System.out.println(a+"H "+b+"M AM");
                          }
                          else
                             System.out.println(a+"H "+b+"M AM");
                      }
                      else if(a>12)
                      {
                         a = a-12;
                         System.out.println(a+"H "+b+"M PM");
                      }
                  }
                  else
                  System.out.println("Invalid Minute");
              }
              else
              System.out.println("Invalid Hour");
              }
              catch(NumberFormatException e)
              {
                  System.out.println(e);
              }
        }
    }
    
    
}
 		