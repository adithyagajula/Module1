package client;
public interface IEmployee {

	abstract void display();
	abstract void addEmployee();
	abstract void calculateAge();
	
}
