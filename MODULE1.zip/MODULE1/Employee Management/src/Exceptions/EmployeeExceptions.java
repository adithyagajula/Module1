package Exceptions;

public class EmployeeExceptions {

}
