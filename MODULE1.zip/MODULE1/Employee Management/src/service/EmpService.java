package service;

public class EmpService {
	public void display()
	{
		
	}

}
