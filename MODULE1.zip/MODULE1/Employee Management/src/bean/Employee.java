package bean;

public class Employee {
	
	Employee(int Id,String Name,String Dept, double Salary, Long CellNo,String Dob)
	{
		
		
	}
	
	public static void main(String[] args) {
		//Employee e = new Employee();
		
	}

}
