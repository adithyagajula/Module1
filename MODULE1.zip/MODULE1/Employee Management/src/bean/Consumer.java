package bean;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable {
	
	BlockingQueue bq;

	public Consumer(BlockingQueue bq) {
		super();
		this.bq = bq;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(bq.remainingCapacity()>0)
		{
			System.out.println(bq.size()+"remaining capacity is "+bq.remainingCapacity());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
