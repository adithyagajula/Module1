package bean;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Main {
	
	public static void main(String[] args) {
		
	
	BlockingQueue queue = new ArrayBlockingQueue(5);
	Producer p = new Producer(queue);
	Consumer c = new Consumer(queue);
	Thread producer = new Thread(p);
	Thread consumer = new Thread(c);
	
	producer.start();
	consumer.start();

}
}
