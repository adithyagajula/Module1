package lab13;

import java.lang.Math;
import java.util.Scanner;


interface printExpression{
	public long print(int x,int y);
}

public class Ex1 {

	public static void main(String[] args)
	{
		printExpression pe=(x,y)->(int) Math.pow(x, y);
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number x");
		int x= sc.nextInt();
		System.out.println("enter number y");
		int y= sc.nextInt();
		long e= pe.print(x,y);
		System.out.println(e);
	}

}

