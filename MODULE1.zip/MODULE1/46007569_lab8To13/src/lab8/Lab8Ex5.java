package lab8;

import java.util.Scanner;

public class Lab8Ex5
{
	int p=0;
	boolean check(String s)
	{
		int l=s.length();
		char[] c=s.toCharArray();
		for(int i=0;i<l-1;i++)
		{
			int a= c[i];
			int b= c[i+1];
			if(a<b)
			{
				p++;//System.out.println("positive string");
			}
		}
		if(p==l-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public static void main(String[] args)
	{
		System.out.println("enter the string");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		Lab8Ex5 e=new Lab8Ex5();
		boolean e1=e.check(s);
		System.out.println(e1);
	}
}
