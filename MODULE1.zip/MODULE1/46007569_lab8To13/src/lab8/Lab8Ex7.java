package lab8;

import java.util.Scanner;

public class Lab8Ex7 
{
	boolean check(String s)
	{
		int l=s.length();
		char[] c=s.toCharArray();
		
		if(l>=12 && c[l-1]=='b'&& c[l-2]=='o'&& c[l-3]=='j'&& c[l-4]=='_')
		{
			return true;
		}
		
		return false;
	}
	public static void main(String[] args) 
	{
		System.out.println("Username must be 8 and ends with  _job  extension... ");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		Lab8Ex7 e=new Lab8Ex7();
		boolean y=e.check(s);
		if(y==true)
		{
			System.out.println("passed / valid");
		}else
		{
			System.out.println("failed  / invalid");
		}
	}
}
