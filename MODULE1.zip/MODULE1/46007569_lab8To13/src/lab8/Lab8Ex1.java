package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8Ex1 
{
	public static void main(String[] args)
	{
		int sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter integers");
		String s1=sc.nextLine();
		 StringTokenizer st=new StringTokenizer(s1," ");
		 System.out.println("each integer value");
		 while(st.hasMoreTokens())
		 { 
			//System.out.println(sum);
			 String s2=st.nextToken();
			 System.out.println("\n"+s2);
			 sum=sum+Integer.parseInt(s2);
		 }
		 System.out.println("sum of all integers");
		 System.out.println(sum);
		sc.close();
	}
}
