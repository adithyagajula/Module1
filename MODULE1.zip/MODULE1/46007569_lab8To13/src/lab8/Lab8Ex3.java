package lab8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab8Ex3 {

	 public static void main(String[] args) throws IOException 
	    { 
	        File file = new File("C:\\Users\\GADITHYA\\Documents\\workspace-sts-3.9.6.RELEASE\\46007569_lab8To13\\Lab8ex2.txt");
	        FileInputStream fileStream = new FileInputStream(file); 
	        InputStreamReader input = new InputStreamReader(fileStream); 
	        BufferedReader reader = new BufferedReader(input); 
	          
	        String line; 
	          
	        // Initializing counters 
	        int countWord = 0; 
	        int sentenceCount = 0; 
	        int characterCount = 0; 
	         
	          
	        // Reading line by line from the  
	        // file until a null is returned 
	        while((line = reader.readLine()) != null) 
	        { 
	          
	            if(!(line.equals(""))) 
	            { 
	                  
	                characterCount += line.length(); 
	                  
	                // \\s+ is the space delimiter in java 
	                String[] wordList = line.split("\\s+"); 
	                  
	                countWord += wordList.length; 
	             
	                  
	                // [!?.:]+ is the sentence delimiter in java 
	                String[] sentenceList = line.split("[!?.:]+"); 
	                  
	                sentenceCount += sentenceList.length; 
	            } 
	        } 
	          
	        System.out.println("Total word count = " + countWord); 
	        System.out.println("Total number of sentences = " + sentenceCount); 
	        System.out.println("Total number of characters = " + characterCount); 
	        
	    } 

}
