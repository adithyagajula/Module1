package lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Lab8Ex2
{
	public static void main(String[] args) throws IOException 
	{
		int i=1;
		FileWriter fw=new FileWriter("Lab8ex2.txt");
		PrintWriter pw = new PrintWriter(fw);
	    pw.println("GAJULA ADITHYA");
	    pw.println("CAPGEMINI");
	    pw.println("adithya");
	    pw.flush();
	    pw.close();
	    FileReader fr=new FileReader("Lab8ex2.txt");
	    BufferedReader br=new BufferedReader(fr);
	    String s=br.readLine();
	    while(s!=null)
	    {
	    	System.out.println((i)+" "+s);
	    	s=br.readLine();
	    	i++;
	    } 
	    
	}
}
