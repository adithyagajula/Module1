import java.util.HashMap;
import java.util.Scanner;


public class MainClass  {

	
public static void main(String[] args) 
	{
		
	
		HashMap<Long,Customer> hm  = new HashMap<Long,Customer>();
		
		while (1 != 0) {
			Scanner sc = new Scanner(System.in);
			System.out.println("1.create 2.balance  3.deposit  4.withdraw  5.fund transfer  6.print transaction ");
			int a1 = sc.nextInt();
			 

			switch (a1) {
			case 1:
				System.out.println("enter your 10 digit mobile number");
				long mobile = sc.nextLong();

				System.out.println("enter your name");
				String name = sc.next();
				
				System.out.println("enter date of birth  :DD:MM:YYYY");
				String dob = sc.next();

				System.out.println("enter new password ");
				String password = sc.next();

				System.out.println("default balance is 100");
				int balance = 100;

				long account = mobile + 2431;
				 Customer c1 =new Customer(name,  password, dob,  mobile, balance, account);
				
				 hm.put(account, c1);

				System.out.println("account is created and number is :" + account);
				System.out.println("account details are");
				System.out.println(hm);
				break;

			case 2:
			
				System.out.println("enter Account number");
				long account1 = sc.nextLong();
			
				Customer ac1 = (Customer) hm.get(account1);
				if (hm.containsKey(account1)) {
					System.out.println("enter password");
					String password1 = sc.next();
					
					if (ac1.getPassword(password1)) {
						System.out.println(ac1.getBalance());
						//ac1.transaction(ac1.getBalance(),a1);
						
						
					}
				}
				break;

			case 3:
				System.out.println("enter your account number");
				long account2 = sc.nextLong();
				 Customer ac2 = ( Customer) hm.get(account2);
				if (hm.containsKey(account2)) {
					System.out.println("enter password");
					String password1 = sc.next();
					if (ac2.getPassword(password1)) {
						System.out.println("enter amount to be deposit");
						int dp1 = sc.nextInt();
						int s11 = ac2.getBalance() + dp1;
						ac2.setBalance(s11);
						System.out.println("balance after deposit");
						System.out.println(ac2.getBalance());
						
					}

				}
				break;

			case 4:
				System.out.println("enter your account number");
				long account3 = sc.nextLong();
				 Customer ac3 = ( Customer) hm.get(account3);
				if (hm.containsKey(account3)) {
					System.out.println("enter password");
					String password1 = sc.next();
					if (ac3.getPassword(password1)) {
						System.out.println("enter amount to be withdrawl");
						int dp1 = sc.nextInt();
						int s11 = ac3.getBalance() - dp1;
						ac3.setBalance(s11);
						System.out.println("balance after withdrawl");
						System.out.println(ac3.getBalance());
						
					}
				}
				break;

			case 5:
					System.out.println("enter account number 1 to transfer");
					long account4 = sc.nextLong();
					System.out.println("enter account number 2 to receive");
					long account5 = sc.nextLong();
					 Customer ac4 = ( Customer) hm.get(account4);
					 Customer ac5 = ( Customer) hm.get(account5);
					if (hm.containsKey(account4) && hm.containsKey(account5)) 
					{
						System.out.println("enter account 1 password");
						String password1 = sc.next();
						System.out.println("enter account 2 password");
						String password2 = sc.next();
						if (ac4.getPassword(password1) && ac5.getPassword(password2)) 
						{
							System.out.println("enter fund amount from account 1 to account 2");
							int fd = sc.nextInt();
							int a11 = ac4.getBalance() - fd;
							int a12 = ac5.getBalance() + fd;
							ac4.setBalance(a11);
							
							ac5.setBalance(a12);
							
							System.out.println("balance account 1 after giving fund :" + ac4.getBalance());
							System.out.println("balance account 2 after receiving fund  :" + ac5.getBalance());
							
							
						}
					}
					break;
			case 6: 
	
				}

			}

	}
}

	

