
public class Customer {
	
	private String Name;
	private String Password;
	private String dob;
	private long Mobile;
	private int Balance;
	private long Account;
	
	
	public long getAccount() {
	return Account;
	}
	public void setAccount(long account) {
		this.Account = Account;
	}
	

	
	public Customer(String name, String password, String dob, long mobile, int balance, long account) {
		super();
		Name = name;
		Password = password;
		this.dob = dob;
		Mobile = mobile;
		Balance = balance;
		Account = account;
	}
	@Override
	public String toString() {
		return "Customer [Name=" + Name + ", Password=" + Password + ", dob=" + dob + ", Mobile=" + Mobile
				+ ", Balance=" + Balance + ", Account=" + Account + "]";
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public long getMobile() {
		return Mobile;
	}
	public void setMobile(long mobile) {
		Mobile = mobile;
	}
	public int getBalance() {
		return Balance;
	}
	public void setBalance(int balance) {
		Balance = balance;
	}
	
	public boolean getPassword(String Password1) {
		// TODO Auto-generated method stub
		if ((Password1).equals(Password)) {
			return true;
		}
		return false;
	}
}
