package lab1;
import java.util.Scanner;

public class SumOfNaturalNumbers1 {
	
	public static void main(String[] args) 
	{
		int number, sum = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.print(" Please Enter any Number : ");
		number = sc.nextInt();	
		SumOfNaturalNumbers1 s=new SumOfNaturalNumbers1();
		sum=s.method(number);
		System.out.println("\n The Sum of Natural Numbers from 1 to "+ number + " = " + sum);
		sc.close();
	}
	public int method(int number)
	{
		int sum=0;
		for(int i = 1; i <= number; i++)
		{
			if(i%3==0||i%5==0)
				
			sum = sum + i; 
		}	
		
	
		return sum;
	}
	}
