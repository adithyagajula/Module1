package lab1;

public class Lab1Ex2 {

	
	    public static void main(String[] args) {
	    	Lab1Ex2 exercise = new Lab1Ex2();
	        System.out.println(exercise.calculateDifference(10));
	        
	    }
	 public int calculateDifference(int n) {
	      int m= (n*(n+1)*(2*n+1))/6;
	      int q =((n*(n+1))/2);
	      q= q*q;
	      int sum = m-q ;
	      return sum;
	 }
}
