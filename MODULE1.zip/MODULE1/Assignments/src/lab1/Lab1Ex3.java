package lab1;

import java.util.Scanner;

public class Lab1Ex3 {
    public static void main(String[] args)
    {
        int num;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number");
        num=scanner.nextInt();
        
        while(num>0)
        {
        	int currentDigit = num%10;
        	int m=num%100;
        	int k=m/10;
            
            if(currentDigit>=k)
            {
            	num=num/10;
                
            }
            else
            {
                System.out.println("Not Increasing");
                break;
            }
            
            if(num<=0) {
            	
            	System.out.println("Increasing");
            }
        }
        scanner.close();
    }
}


