package lab3;

import java.util.Scanner;
import java.util.Arrays;
public class ArrayString
{
	void method12(String s11[],int i1)
	{
		
		int k=i1/2;
		if(i1%2!=0)
		{
			k=k+1;
		}
		for(int i=0;i<i1;i++)
		{
			if(i<k)
			{
				System.out.println(s11[i].toUpperCase());
			}
			else
			{
				System.out.println(s11[i].toLowerCase());
			}
		}
	}
	public static void main(String[] args )
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array size");
		int i1=sc.nextInt();
		String s11[]= new String [i1];
		System.out.println("enter data");
		for (int i=0;i<i1;i++)
		{
		 s11[i]=sc.next();
		}
	    Arrays.sort(s11);
		//System.out.println(s11);
		ArrayString e=new ArrayString();
		e.method12(s11, i1);
		sc.close();
	}
}
