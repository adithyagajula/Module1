package lab3;

import java.util.Scanner;

public class ReverseArray {
	public void getSorted(int a[])
	{

	for(int i=0;i<a.length;i++)
	{
		for(int j=0;j<a.length;j++)
		{
	
		if (a[i]<a[j])
		{
			int temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
		}
	}
	}
	
	public static void main(String[] args) {
	
					
			int a[]=new int[6];
			System.out.println("enter numbers ");
			for(int i=0;i<a.length;i++)
			{
				
				
				Scanner s = new Scanner(System.in);
				a[i]=s.nextInt();
				s.close();
				
				
			}
			for(int k=a.length-1;k>=0;k--)
			{
				
				System.out.print(" " +a[k]);
				
			}
			System.out.println();
			
			ReverseArray r = new ReverseArray();
			r.getSorted(a);
			for(int j=0;j<a.length;j++)
			{
				System.out.print(" " +a[j]);
			}
			
			
		}
}
