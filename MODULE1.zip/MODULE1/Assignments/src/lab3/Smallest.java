
package lab3;
import java.util.Scanner;

public class Smallest {
	

	
	public int getSmallest(int a[])
	{
		
		
		for(int i = 0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
		
			if (a[i]<a[j])
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
					

			
			
		}
			
		}
		
		for(int k=0;k<a.length;k++)
		{
			System.out.println("sorted num are :" +a[k]);
		}
		return a[1];
		
		
	}

	public static void main(String[] args) {
		
		int a[]=new int[6];
		
		System.out.println("enter numbers : ");
		
		Scanner s=new Scanner(System.in);
		
		for(int i = 0;i<a.length;i++)
		{
			
			a[i]=s.nextInt();
		}
		
		Smallest small = new Smallest();
		
		
		System.out.println("second smallest num is :" +small.getSmallest(a));
		s.close();
		
	}
}
