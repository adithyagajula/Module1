package lab5;
import java.util.Scanner;
public class TrafficLight {
    public static void main(String args[]) {
        System.out.println("Enter Signal");
        Scanner sc=new Scanner(System.in);
        String signal=sc.nextLine();
        switch(signal)
        {
        case "red":
            System.out.println("STOP");
            break;

 

        case "yellow":
            System.out.println("READY");
            break;

 

        case "green":
            System.out.println("GO");
            break;
        default:
            System.out.println("select");
        }
sc.close();
 

    }    
}