package lab5;


	import java.util.Scanner;

	public class Sam {
		void validation(int n) throws MyException{
			if(n<15)
			{
				throw new MyException("Age should be above 15");
			}
			else 
			{
				System.out.println("Age criteria Fulfilled");
			}
		}
		public static void main(String[] args) {
			Sam age=new Sam();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Age");
			int n=sc.nextInt();
			try
			{
				age.validation(n);
			}
			catch(MyException e)
			{
				System.out.println(e);
			}
			//sc.close();
		}
	}
