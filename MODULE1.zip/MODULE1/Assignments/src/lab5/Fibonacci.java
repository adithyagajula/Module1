package lab5;

import java.util.Scanner;
public class Fibonacci {
    
    public int rfib(int m) {
        if(m==1) {
            return 0;
        }
        else if(m==2) {
            return 1;
        }
        
        int k=rfib(m-1)+rfib(m-2);
        return k;
    }
    public int nfib(int m) {
        int a=0,b=1,c=0,i=2;
        while(i<m) {
            c=a+b;
            a=b;
            b=c;
            i++;
        }
        return c;
        
        
    }
    public static void main(String args[])
    {
        int n;
        
        Fibonacci f=new Fibonacci();
        Scanner s=new Scanner(System.in);
        System.out.println("Enter n");
        n=s.nextInt();
        s.close();
        System.out.println("Fibonacci number "+"Using Recursive is"+f.rfib(n)+" Using Non recursive is"+f.nfib(n));
    }

 

}