package lab5;

import java.util.Scanner;

public class AllPrimes {
public static void main(String args[]) {
    int n;
    System.out.println("enter n");
    Scanner s=new Scanner(System.in);
    n=s.nextInt();
    for(int i=2;i<=n;i++)
    {
        int m=0;
        for(int j=1;j<=i;j++)
        {
            if(i%j==0)
            {
                m++;
            }
        }
         
       if(m==2)
        {
            System.out.println(i);
        }
    }
    s.close();
}
} 