package lab5;

import java.util.Scanner;
public class NameValidation {

	void validation(String s1,String s2) throws MyException{
		if(s1.isEmpty())
		{
			throw new MyException("missing Firstname");
		}
		else if(s2.isEmpty())
		{
			throw new MyException("missing Lastname");
		}
		else 
		{
			System.out.println("s1+s2");
		}
	}
	public static void main(String[] args) {
		NameValidation n=new NameValidation();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Firstname");
		String f=sc.nextLine();
		System.out.println("Enter Lastname");
		String l=sc.nextLine();
		try
		{
			n.validation(f, l);
	    }
		catch(MyException e)
		{
			System.out.println(e);
		}
		sc.close();
	}
}
