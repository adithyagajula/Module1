package com.cg.eis.exception;


import java.util.Scanner;

public class SalaryCheck {
	void validation(int n) throws EmployeeException{
		if(n<3000)
		{
			throw new EmployeeException("Salary is Less");
		}
		else 
		{
			System.out.println("Salary criteria Fulfilled");
		}
	}
	public static void main(String[] args) {
		SalaryCheck sal=new SalaryCheck();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Salary");
		int n=sc.nextInt();
		try
		{
			sal.validation(n);
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		sc.close();
	}
}

