package DAO;

public class AccountNotFoundException extends RuntimeException {
	public AccountNotFoundException(String s) {
		super(s);
	}
}

