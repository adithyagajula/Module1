
class Calculator
{
	int num1=100;
	int num2=50;
	int res;


	public void add()
	{
		res=num1+num2;
		System.out.println("sum is =" +res);
		
	}
	public void subract()
	{
		res=num1-num2;
		System.out.println("sub is =" +res);
	}
	public void multi()
	{
		res=num1*num2;
		System.out.println("multi num is =" +res);
	}
	public void div()
	{
		float res=num1/num2;
		System.out.println("div num is =" +res);
	}
	}
public class HelloWorld {
	
	
public static void main(String args[])
{
	
System.out.println("Hello Java");

Calculator s = new Calculator();
//HelloWorld hello=new HelloWorld();
s.add();
s.subract();
s.div();
s.multi();


}
}
