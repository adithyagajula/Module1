import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerialDemo {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileOutputStream obj = new FileOutputStream("employee.ser");
		
		Employee e = new Employee();
		e.setId(123);
		e.setName("adithya");
		e.setCell(1234567);
		e.setSalary(50000);
		ObjectOutputStream obj1=new ObjectOutputStream(obj);
		obj1.writeObject(e);
		obj1.close();
		FileInputStream fis = new FileInputStream("employee.ser");
		//fis.read();
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		System.out.println(ois.readObject());
	}

}
