interface Sayable{
	void say();
	
}
public class Hello implements Sayable {

	public void saySomething() {
		System.out.println("Hello this is static method");
	}
	public static void main(String[] args) {
		Hello ref=new Hello();
		Sayable sayable = ref::saySomething;
		sayable.say();
		Sayable sayable2 = new Hello()::saySomething;
		sayable2.say();
	}
	@Override
	public void say() {
		// TODO Auto-generated method stub
		
	}
}
