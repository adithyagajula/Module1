//////////////////////////////////////////////////////////////////////////////////////////////////
public class Car2 implements Vehicle2 {

	@Override
	public void wheels() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gears() {
		// TODO Auto-generated method stub

	}

}
