
public abstract class Vehicle {
	public Vehicle()
	{
		System.out.println("vehicle def cons..");
		
	}
	public abstract void milage();
	public abstract void speed();
	public void transport()
	{
		System.out.println("travel");
	}
	

}
