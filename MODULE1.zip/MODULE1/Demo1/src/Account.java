
public class Account {

	public void savings()
	{
		System.out.println("1000");
		
	}
	public void withDraw()
	{
		System.out.println("500");
	}
}
