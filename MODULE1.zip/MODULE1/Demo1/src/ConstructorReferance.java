import java.util.function.Supplier;

public class ConstructorReferance {
	public static void main(String[] args) {
		
		Supplier<Item> s1=Item::new;
		s1.get().setName("Mobiles");
		System.out.println(s1.get().getName());
	}

}
