
public class Sample {

	private String username;
	private String password;
	public Sample(String username, String password) {
		super();
		this.username = username;
		this.password = password;
		System.out.println(this.username+" "+this.password);
	}

	public Sample() {
		super();
		System.out.println("default constructor");
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Sample sample = new Sample();
		Sample s1 = new Sample("Adithya", "Gajula");
	}
	
}
