
public interface Vehicle2 {

	public void wheels();
	public void gears();
}
