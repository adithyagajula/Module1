
public class SavingaAccount extends Account {

	public static void main(String[] args) {
		
		SavingaAccount s = new SavingaAccount();
		s.savings();
		s.withDraw();
	}
}
