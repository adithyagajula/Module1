public class TryCatchExample {  
  
	
	
	public void divide(int x)
	{
		if(x>50)
			throw new IllegalArgumentException("result is");
		
	}
	
	public static void main(String args[]){  
		
		  try{  
			 // String name=null;
			 // System.out.println(name.length());
			  
			  TryCatchExample t=new TryCatchExample();
			  t.divide(70);
			  
		 //  int data=25/0;  
		   int arr[]=new int[5];
		   
		 //  System.out.println(data); 
		   for(int i=0;i<10;i++)
		   {
			   arr[i]=i++;
			   
		   }
		   
		   
		   
		  }  
		  catch(ArithmeticException e){
			  System.out.println(e);
			  }  
		  catch(ArrayIndexOutOfBoundsException e)
		  {
			  System.out.println(e);
			  
		  }
		  catch(NullPointerException e)
		  {
			  
			  System.out.println(e);
		  }
		  catch(IllegalArgumentException e)
		  {
			  
			  System.out.println(e);
		  }
		  finally{
			  System.out.println("finally block is always executed");
			  
		  }  
		  System.out.println("rest of the code...");  
		  
		  }  
		}