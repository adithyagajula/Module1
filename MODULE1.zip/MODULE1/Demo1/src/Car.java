
public class Car extends Vehicle {

	public Car()
	{
		super();
		System.out.println("car def cons...");
	}
	@Override
	public void milage() {
		// TODO Auto-generated method stub
		System.out.println("milage is 28");

	}

	@Override
	public void speed() {
		// TODO Auto-generated method stub
		System.out.println("speed is 140");

	}
public static void main(String[] args) {
	//Car c = new Car();
	Vehicle c = new Car();
	c.milage();
	c.speed();
	c.transport();
}
}
