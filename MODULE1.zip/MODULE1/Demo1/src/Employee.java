import java.io.Serializable;

public class Employee implements Serializable{
	private int id;
	public double cell;
	public double getCell() {
		return cell;
	}

	public void setCell(double cell) {
		this.cell = cell;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	private String name;
	private transient double salary;
	
public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	//public int getSalary() {
	//	return salary;
	//}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String toString() {
	
	return +id+" "+salary+" "+name+" "+cell;

	}
}
