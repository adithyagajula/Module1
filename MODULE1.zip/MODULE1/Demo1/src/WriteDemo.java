import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteDemo {

	public static void main(String[] args) throws IOException  {
		String str="my name is adithya";
		FileOutputStream obj = new FileOutputStream("adithya.txt");
		obj.write(str.getBytes());
		
		obj.close();
		
		DataOutputStream d = new DataOutputStream(obj);
		int i=4;
		d.writeInt(i);
		d.close();
		
		FileInputStream obj1 = new FileInputStream("adithya.txt");
		
		obj1.read(str.getBytes());
		DataInputStream b = new DataInputStream(obj1);
		
		
		
	//	b.write(1);
		//b.write((int) 2.3f);
	}
}
