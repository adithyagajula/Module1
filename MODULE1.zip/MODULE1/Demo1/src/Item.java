
public class Item {
	private String name="Unknown";
	private double price=0.0;
	
	public Item() {
		System.out.println("Default");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
