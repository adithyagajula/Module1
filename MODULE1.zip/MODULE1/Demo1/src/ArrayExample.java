import java.util.Scanner;

public class ArrayExample {

	Scanner s = new Scanner(System.in);
	
	
	//a[i]=s.nextInt();
	
	
	public int custID()
	{
		System.out.println("enter cust id : ");
	return s.nextInt();
	
	}
	
	public String custName()
	{
		
		System.out.println("enter cust name :");
		 return s.next();
	}

	public static void main(String[] args) {
		//int a[]=new int[10];
		int c[]=new int[10];
	String g[]=new String[10];
		for(int i=0;i<3;i++)
		{
		
		System.out.println("emter employee details : ");
		
		ArrayExample b = new ArrayExample();
		
		c[i]=b.custID();
		g[i]=b.custName();
		}
		
		for(int j=0;j<3;j++)
		{
			
			System.out.println("cust details are :" +c[j] +"  "+g[j]);
		}
	}
}
