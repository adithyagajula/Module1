import java.time.LocalDate;
import java.time.Month;

public class LocalDateDemo {
	public static void main(String[] args) {
		LocalDate currentdate=LocalDate.now();
		LocalDate IndependanceDay = LocalDate.of(1947,Month.AUGUST,15);
		System.out.println("Independace: "+IndependanceDay);
		System.out.println("Today: "+currentdate);
		System.out.println("Tomorrow : "+currentdate.plusDays(1));
		System.out.println("Last month : "+currentdate.minusMonths(1));
		System.out.println("Is Leap? : "+currentdate.isLeapYear());
		System.out.println("Move to 30th day of month : "+currentdate.withDayOfMonth(30));
		System.out.println("Number of days in this month : "+currentdate.lengthOfMonth());
	}

}
