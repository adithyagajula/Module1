package com.cg.ui;

import java.util.Scanner;

public class CustomerUI {
	
	public static void main(String[] args) {
		System.out.println("ENTER CUST details");
		
		Scanner s = new Scanner(System.in);
		 
		int custID = s.nextInt();
		System.out.println("Eenter id");
		
		String name = s.next();
		System.out.println("enter cust name");
		
		Long cellNo = s.nextLong();
		System.out.println("enter cust cellNo");
		
		
		
		
		
	}

}
