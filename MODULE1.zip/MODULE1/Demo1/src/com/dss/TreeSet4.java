package com.dss;

import java.util.TreeSet;



public class TreeSet4 {
    public static void main(String[] args) {
        TreeSet<Integer> t=new TreeSet<Integer>(new MyComparator());
        t.add(3);
        t.add(7);
        t.add(50);
        t.add(75);
       // TreeSet<Object> tReverse = (TreeSet<Object>)t.descendingSet();
       // System.out.println("descending order"+tReverse);
        System.out.println(t.comparator());
    }

 

}



