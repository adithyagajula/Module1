package com.dss;
import java.util.ArrayList;

import java.util.Iterator;

public class CollEx2 {

	public static void main(String[] args) {
		
		ArrayList<String> a1 = new ArrayList<String>();

a1.add(111,"adithya");
a1.add(123,"gajula");
		
		
		
		Iterator<String> itr = a1.iterator();
		while(itr.hasNext())
		{
			String s = (String)itr.next();
			System.out.println(s);
		}
}
}
