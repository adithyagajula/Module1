package com.dss;

import java.util.ArrayList;
import java.util.Iterator;



public class CollEx1 {

	public static void main(String[] args) {
		
		ArrayList<String> a1 = new ArrayList<String>();
		a1.add("JAVA");
		a1.add("j2ee");
		a1.add("php");
		a1.add("python");
		
		Iterator<String> itr = a1.iterator();
		while(itr.hasNext())
		{
			String s = (String)itr.next();
			System.out.println(s);
		}
		//Iterator
	}
}
