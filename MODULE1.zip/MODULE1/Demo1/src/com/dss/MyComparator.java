package com.dss;

import java.util.Comparator;



//import org.omg.CORBA.OMGVMCID;

 

public class MyComparator implements Comparator<String> {

 

    @Override
    public int compare(String o1, String o2) {
        // TODO Auto-generated method stub
        return o2.compareToIgnoreCase(o1);
    }
    
}