package com.dss;

import java.util.TreeSet;

public class TreeSet1 {

	public static void main(String[] args) {
		
		TreeSet<String> t = new TreeSet<>();
		t.add("python");
		t.add("java");
		t.add("j2ee");
		t.add("php");
		
		System.out.println(t.comparator());
		System.out.println(t);
		 TreeSet<Integer> t1 = new TreeSet<Integer>();
		 t1.add(1);
		 t1.add(50);
		 t1.add(23);
		 t1.add(11);
		 t1.add(100);
		 System.out.println(t1);
		 System.out.println(t1.comparator());
		 
		
	}
}
