package com.dss;

 
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

public class HashSorting {

	public static void main(String[] args) {
		
		HashSet<Integer> h = new HashSet<Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter n value");
		int i=0;
		while(i<=5)
		{
			int n=sc.nextInt();
			h.add(n);
			i++;
		}
	/*h.add(1);
	h.add(50);
	h.add(20);
	h.add(45);*/
	System.out.println(h);
	
	HashSet<String> h1 = new HashSet<String>();
	System.out.println(h1.add("java"));
	System.out.println(h1.add("jav"));
	System.out.println(h1.add("spring"));
	System.out.println(h1);
	
	ArrayList<Integer> a1 = new ArrayList<Integer>(h);
	Collections.sort(a1);
	System.out.println(a1);
	
	}
}
