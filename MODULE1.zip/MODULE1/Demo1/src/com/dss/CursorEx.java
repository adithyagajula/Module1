package com.dss;



	
	import java.util.ArrayList;
	import java.util.Enumeration;
	import java.util.Iterator;
	import java.util.ListIterator;
	import java.util.Vector;

	 
	public class CursorEx {
	
	    public static void main(String[] args) {
	        ArrayList<Integer> a1=new ArrayList<Integer>();
	        a1.add(20);
	        a1.add(50);
	        a1.add(16);
	        a1.add(89);
	        Vector<Integer> v=new Vector<Integer>(a1);
	        Enumeration<Integer> e1=v.elements();
	        while(e1.hasMoreElements()) {
	            System.out.println(e1.nextElement());
	        }
	        
	        Iterator<Integer > i=v.iterator();
	        while(i.hasNext()) {
	            System.out.println(i.next());
	        }
	        
	        ListIterator<Integer> li =v.listIterator();
	        while(li.hasNext()) {
	            System.out.println(li.next());
	        }
	        
	        System.out.println(v);
	        
	    }

	 

	}

