package com.dss;

public class MT {
	public static void main(String[] args) throws InterruptedException {
		
		ThreadB b = new ThreadB();
		b.start();
		synchronized(b) {
			
			System.out.println("main calling wait");
			b.wait();
			System.out.println("got notification");
		}
	}
		
	//9481475846
	
	class ThreadB extends Thread
	{
		public void run()
		{
			synchronized (this) {
				System.out.println("user thread got the lock");
				this.notify();
				
			}
		}
	}
	}
}
