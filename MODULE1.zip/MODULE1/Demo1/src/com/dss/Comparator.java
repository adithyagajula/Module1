package com.dss;

public interface Comparator {
	
	

}
