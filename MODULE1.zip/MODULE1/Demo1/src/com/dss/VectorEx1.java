package com.dss;

import java.util.ArrayList;
import java.util.Vector;

public class VectorEx1 {

	public static void main(String[] args) {
		
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("java");
		a1.add("j2ee");
		a1.add("python");
		System.out.println(a1);
		Vector<String> v = new Vector<String>(a1);
		v.add("adithya");
		v.add("gajula");
		System.out.println(v);
		for(String v1:v)
		{
			System.out.println(v1);
		}
		
		
	}
}
