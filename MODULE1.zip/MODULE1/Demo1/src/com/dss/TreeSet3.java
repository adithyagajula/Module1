package com.dss;
import java.util.TreeSet;



public class TreeSet3 {
    public static void main(String[] args) {
        TreeSet<String> ts=new TreeSet<>(new MyComparator());
        ts.add("nil");
        ts.add("asd");
        ts.add("bcvb");
        ts.add("capg");
        ts.add("hariv");
        System.out.println(ts);
    }
        
}
