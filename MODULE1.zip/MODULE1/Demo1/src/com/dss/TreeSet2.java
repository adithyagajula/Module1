package com.dss;


import java.util.TreeSet;

public class TreeSet2 {

	public static void main(String[] args) {
		
		TreeSet<String> t = new TreeSet<>();
		t.add("aaa");
		t.add("zzz");
		t.add("kkk");
		t.add("lll");
		
		//System.out.println(t.comparator());
		System.out.println(t);


}
}
