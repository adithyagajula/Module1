
public class MainClass {
public static void main(String args[])
{
Login login = new Login();
login.setUsername("adithya");
login.setPassword("gajula");
System.out.println("username is" +login.getUsername());
System.out.println("password is" +login.getPassword());
}

}
