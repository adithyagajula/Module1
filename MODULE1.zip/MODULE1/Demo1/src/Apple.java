
public class Apple {

	public String color="green";
}
