
public class AgeException extends Exception1 {
	private int age;
	AgeException(int a){
		age=a;
	}
	

public String toString()
{
return age+"is an invalid age";	
}
}