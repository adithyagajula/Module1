import java.util.Scanner;

public class Exception1 {
	public static void main(String[] args) {
		int age;
		
		Scanner s=new Scanner(System.in);
		age=s.nextInt();
		if(age<18)
		{
		try
		{
			throw new Exception("not eligible to vote");
			
			}
		catch (Exception e)
		{
			
System.out.println("not eligible to vote");

}
		}
		else
			System.out.println("you can vote");
		}
		
	}

