

public class switchdemo {

	public static void main(String[] args) {
		
	
	String currentDay = args[0];
	/*
	int empId[];
	empId=new int[40];       //DT arrayName[]=new DT[size]
	
	int a=25;*/
	
	switch(currentDay)
	{
	case"Monday":
	System.out.println("after sunday :( ");
	break;
	
	case"Tuesday":
	System.out.println("Tuesday :( ");
	break;
	
	case"Wednesday":
	System.out.println("betterday :( ");
	break;
	
	default:
	System.out.println("otherday :( ");
	
	
	}
}
}
