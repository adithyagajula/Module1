import java.util.Scanner;

public class Arraydemo {

	public static void main(String[] args) {
		
		
		int cust[]=new int[10];
		for(int i=0;i<cust.length;i++)
		{
			
			System.out.println("enter numbers ");
			Scanner s = new Scanner(System.in);
			cust[i]=s.nextInt();
			
			
		}
		for(int j=0;j<cust.length;j++)
		{
			System.out.print(" " +cust[j]);
		}
		
	}
}
